package by.mankevich.task05fragments


data class Contact(var name: String, var surname: String, var number: String, var photo: Photo) {
    fun getFullName(): String {
        return name.plus(" ").plus(surname)
    }
}
