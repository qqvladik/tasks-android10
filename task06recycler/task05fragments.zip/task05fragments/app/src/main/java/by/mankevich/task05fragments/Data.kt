package by.mankevich.task05fragments

const val KEY_JSON_CONTACTS = "Contacts"

object Data {
    var contacts: MutableList<Contact> = mutableListOf(
        Contact("Vlad", "Mankevich", "+375445313884", Photo("https://picsum.photos/200/300")),
        Contact("Eugene", "Mankevich", "80291111111", Photo("https://picsum.photos/200/300")),
        Contact("Mommy", "", "80123456789", Photo("https://picsum.photos/200/300")),
        Contact("Dad", "", "80987654321", Photo("https://picsum.photos/200/300"))
    )

    var filteredContacts: MutableList<Contact> = ArrayList(contacts)

    var isEdited = false
    var isAdded = false
    var isTablet = false
}